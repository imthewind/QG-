#define _CRT_SECURE_NO_WARNINGS

#ifndef __SQSTACKMAIN_H__
#define __SQSTACKMAIN_H__

#define STACK_MAXSIZE 10000	
#define STACK_ADD 10

#include "Sqinterface.h"
#include "SqStack.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

extern int error_handle();//����������
extern int input();//���뺯��

#endif // !__MAIN_H__
